import { Telegraf } from "telegraf";
import { message } from "telegraf/filters";

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const GAS_URL = process.env.GOOGLE_APPS_SCRIPT_URL;
const PORT = process.env.PORT || 3000;

if (!BOT_TOKEN) throw new Error("TELEGRAM_BOT_TOKEN is required");
if (!GAS_URL) throw new Error("GOOGLE_APPS_SCRIPT_URL is required");

const bot = new Telegraf(BOT_TOKEN);

function parseMessage(text) {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  let date = null;
  const ids = [];

  for (const line of lines) {
    if (line.toLowerCase().startsWith("wd date")) {
      const colonIdx = line.indexOf(":");
      if (colonIdx !== -1) date = line.slice(colonIdx + 1).trim();
    } else {
      ids.push(line);
    }
  }
  return { date, ids };
}

bot.on(message("text"), async (ctx) => {
  const msg = ctx.message;
  const chatType = msg.chat.type;
  if (chatType !== "group" && chatType !== "supergroup") return;

  const { date, ids } = parseMessage(msg.text);
  if (ids.length === 0) return;

  const firstName = msg.from?.first_name ?? "Unknown";
  const extractedDate = date ?? "N/A";
  const idLines = ids.map((id) => `ID : <code>${id}</code>`).join("\n");

  const replyText =
    `Remark: Late WD 1 day up\n\n` +
    `Web : ${firstName}\n\n` +
    `WD Date : ${extractedDate}\n` +
    idLines;

  try {
    await ctx.reply(replyText, {
      parse_mode: "HTML",
      reply_parameters: { message_id: msg.message_id },
    });
  } catch (err) {
    console.error("Failed to send reply:", err.message);
    return;
  }

  try {
    const res = await fetch(GAS_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sheetName: firstName,
        date: extractedDate,
        remake: "Late WD 1 day up",
        ids,
      }),
    });
    if (!res.ok) {
      console.warn("Google Apps Script responded with status:", res.status);
    } else {
      console.log(`Posted to sheet: ${firstName} | IDs: ${ids.join(", ")}`);
    }
  } catch (err) {
    console.error("Failed to POST to Google Apps Script:", err.message);
  }
});

// Health check server so UptimeRobot / Replit Reserved VM stays alive
import http from "http";
const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ status: "ok" }));
});

server.listen(PORT, () => {
  console.log(`Health check server running on port ${PORT}`);
});

bot.launch({ dropPendingUpdates: true }).then(() => {
  console.log("Telegram bot started (polling)");
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
